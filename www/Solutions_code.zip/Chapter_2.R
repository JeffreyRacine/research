###################################################
### chunk number 1: 
###################################################
options(prompt = "R> ", np.messages = FALSE, digits = 3, scipen = 3)
library(np)


###################################################
### chunk number 2: 
###################################################
data(cps71)
attach(cps71)
model.lc <- npreg(logwage~age,regtype="lc")
model.ll <- npreg(logwage~age,regtype="ll")
model.ols <- lm(logwage~age+I(age^2))


###################################################
### chunk number 3: 
###################################################
plot(age,logwage,cex=0.25,col="gray")
lines(age,fitted(model.lc),lty=1,lwd=2,col="red")
lines(age,fitted(model.ll),lty=2,lwd=2,col="blue")
lines(age,fitted(model.ols),lty=3,lwd=2,col="green")
legend(20,15,c("Local Constant","Local Linear","Quadratic OLS"),
       lty=c(1,2,3),
       col=c("red","blue","green"))


###################################################
### chunk number 4: 
###################################################
    plot(model.lc,plot.errors.method="asymptotic",
         plot.errors.style="band")


###################################################
### chunk number 5: 
###################################################
    plot(model.ll,plot.errors.method="asymptotic",
         plot.errors.style="band")


