###################################################
### chunk number 1: 
###################################################
options(prompt = "R> ", np.messages = FALSE, digits = 3, scipen = 3)
library(np)


###################################################
### chunk number 2: 
###################################################
data(cps71)
attach(cps71)
fhat <- npcdens(logwage~age,bwmethod="cv.ls")
summary(fhat)


###################################################
### chunk number 3: 
###################################################
plot(fhat,view="fixed",phi=85)


