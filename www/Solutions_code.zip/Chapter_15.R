###################################################
### chunk number 1: 
###################################################
options(prompt = "R> ", np.messages = FALSE, digits = 3, scipen = 3)
library(np)


###################################################
### chunk number 2: 
###################################################
library(mgcv) 
data(wage1) 
attach(wage1)
model.gam <- gam(lwage~s(educ)+s(exper)+s(tenure),method="GACV.Cp") 
plot(model.gam,se=T) 


###################################################
### chunk number 3: 
###################################################
options(SweaveHooks = list(multifig = function() par(mfrow=c(2,2),mar=c(4,4,3,2))))
plot(model.gam,se=T) 


