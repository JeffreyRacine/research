library(plm)
library(Ecdat)

data(Airline)

z <- plm(log(cost) ~ log(output) + log(pf) + lf,
         model = "within",
         index=c("airline", "year"),
         data = Airline)

summary(z)

#Usage:
#
#     data(Airline)
#
#Format:
#
#     A dataframe containing :
#
#     airline airline
#
#     year year
#
#     cost total cost, in $1,000
#
#     output output, in revenue passenger miles, index number
#
#     pf fuel price
#
#     lf load factor, the average capacity utilization of the fleet
#

##

library(np)
options(np.messages=FALSE)

attach(Airline)

lcost <- as.numeric(log(cost))
loutput <- as.numeric(log(output))
lpf <- as.numeric(log(pf))
lf <- as.numeric(lf)

bw <- npregbw(lcost~loutput +
              lpf +
              lf +
              ordered(year) +
              factor(airline),
              regtype="ll",
              bwmethod="cv.aic",
              ukertype="liracine",
              okertype="liracine",
              nmulti=100)

summary(bw)

model <- npreg(bws=bw,gradients=TRUE)

summary(model)

postscript(file="mean.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,xtrim=0.1,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

postscript(file="grad.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,xtrim=0.1,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,gradients=TRUE,common.scale=FALSE)
dev.off()
