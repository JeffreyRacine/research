library(np)
options(np.messages=FALSE)

data(wage1)

#bw.all <- npregbw(formula=lwage~factor(female)+
#                  factor(married)+
#                  educ+
#                  exper+
#                  tenure,
#                  regtype="ll",
#                  bwmethod="cv.aic",
#                  data=wage1)

#save(bw,file="bw.RData")

summary(bw.all)

model.np <- npreg(bws=bw.all)

summary(model.np)

postscript(file="mean.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw.all,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

postscript(file="grad.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw.all,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,gradients=TRUE,common.scale=FALSE)
dev.off()
