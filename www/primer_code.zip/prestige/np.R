library(np)
library(KernSmooth)
library(bootstrap)
data <- read.table("prestige.dat",header=TRUE)
attach(data)

## Plug-in

h <- dpill(income, prestige)
model.plugin <- locpoly(income, prestige, bandwidth = h)

## Under

bw <- npregbw(prestige~income,bws=c(sd(income)*length(income)^{-1/5}/10),regtype="ll",bandwidth.compute=FALSE)

fit.under <- fitted(npreg(bws=bw))

## Over

bw <- npregbw(prestige~income,bws=c(1000*sd(income)*length(income)^{-1/5}),regtype="ll",bandwidth.compute=FALSE)

fit.over <- fitted(npreg(bws=bw))

## LL CV

bw <- npregbw(prestige~income,bwmethod="cv.ls",regtype="ll")

fit.ls <- fitted(npreg(bws=bw))

## LL CV

bw <- npregbw(prestige~income,bwmethod="cv.aic",regtype="ll")

fit.aic <- fitted(npreg(bws=bw))

##

postscript(file="multiplot.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")

par(mfrow=c(2,2))

plot(income,prestige,xlab="Income (K)", ylab="Prestige",main="Undersmoothed")
lines(income,fit.under)

plot(income,prestige,xlab="Income (K)", ylab="Prestige",main="Oversmoothed")
lines(income,fit.over)

plot(income,prestige,xlab="Income (K)", ylab="Prestige",main="Plug-In")
lines(model.plugin$x,model.plugin$y)

plot(income,prestige,xlab="Income (K)", ylab="Prestige",main="AIC & CV")
lines(income,fit.ls,lty=1)
lines(income,fit.aic,lty=2)

dev.off()
