library(np)
options(np.messages=FALSE)

data(wage1)
attach(wage1)

## Linear

model.ols <- lm(formula=lwage~factor(female)+
                factor(married)+
                educ+
                exper+
                tenure,
                x=TRUE,
                y=TRUE,
                data=wage1)

X <- data.frame(factor(wage1$female),
                factor(wage1$married),
                wage1$educ,
                wage1$exper,
                wage1$tenure)

output <- npcmstest(model = model.ols, 
                    xdat = X, 
                    ydat = wage1$lwage)

summary(output)

## Quadratic

model.ols <- lm(formula=lwage~factor(female)+
                factor(married)+
                educ+
                exper+
                I(exper^2)+                
                tenure,
                x=TRUE,
                y=TRUE,
                data=wage1)

X <- data.frame(factor(wage1$female),
                factor(wage1$married),
                wage1$educ,
                wage1$exper,
                wage1$tenure)

output <- npcmstest(model = model.ols, 
                    xdat = X, 
                    ydat = wage1$lwage)

summary(output)
