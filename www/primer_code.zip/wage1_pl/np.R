library(np)
options(np.messages=FALSE)

data(wage1)

model.lm <- lm(formula=lwage~factor(female)+
               factor(married)+
               educ+
               tenure+
               exper+
               I(exper^2),
               data=wage1)

summary(model.lm)

bw <- npplregbw(formula=lwage~factor(female)+
                factor(married)+
                educ+
                tenure|exper,
                data=wage1)

model.pl <- npplreg(bw)

summary(model.pl)

coef(model.pl)
model.pl$xcoeferr

postscript(file="mean.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

