set.seed(12345)

n <- 250

x <- sort(c(rnorm(n,mean=-2,sd=0.5),rnorm(n,mean=3,sd=1.5)))

mean(x)
sd(x)

x.seq <- seq(min(x),max(x),length=100)
set.seed(12345)

n <- 250

x <- sort(c(rnorm(n,mean=-2,sd=0.5),rnorm(n,mean=3,sd=1.5)))

mean(x)
sd(x)

x.seq <- seq(min(x),max(x),length=100)
set.seed(12345)

n <- 250

x <- sort(c(rnorm(n,mean=-2,sd=0.5),rnorm(n,mean=3,sd=1.5)))

mean(x)
sd(x)

x.seq <- seq(min(x),max(x),length=100)

postscript(file="gaussian.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(x,dnorm(x,mean=mean(x),sd=sd(x)),xlab="X",ylab="Normal Density",ylim=c(0,0.42),type="l",main="",col="blue",lty=1)
lines(x,0.5*dnorm(x,mean=-2,sd=0.5)+0.5*dnorm(x,mean=3,sd=1.5),col="red",lty=2)
dev.off()

shapiro.test(x)

postscript(file="histogram_kernel.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
hist(x,xlab="X",ylab="Histogram, Kernel Density",main="",prob=TRUE,lwd=2,ylim=c(0,0.42))
lines(density(x),col="blue",lwd=2)
dev.off()

postscript(file="histogram.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
hist(x,xlab="X",ylab="Histogram",main="",prob=TRUE)
dev.off()

postscript(file="kernel.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(density(x),xlab="X",ylab="Kernel Density",main="")
dev.off()

### 
library(np)
bw <- npudensbw(~x,bws=density(x)$bw,bandwidth.compute=FALSE)
#postscript(file="kernel_ci.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
#plot(bw,xtrim=-0.4,plot.errors.method="bootstrap",plot.errors.style="band",neval=100,plot.errors.center="bias-corrected",plot.errors.boot.num=399)
#dev.off()

x.seq <- data.frame(x=seq(-5,8,length=100))
fhat <- npudens(bws=bw,newdata=x.seq)
se.fhat <- se(fhat)
fit.fhat <- fitted(fhat)

postscript(file="kernel_ci.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(x.seq$x,fit.fhat,ylim=c(0,max(fit.fhat+1.96*se.fhat)),xlab="X",ylab="Density",type="l",main="",col="blue",lty=1)
lines(x.seq$x,fit.fhat-1.96*se.fhat,col="red",lty=2)
lines(x.seq$x,fit.fhat+1.96*se.fhat,col="red",lty=2)
dev.off()

bw <- npudensbw(~x,bwmethod="cv.ls")

postscript(file="kernel_lscv.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(density(x),ylim=c(0,0.42),xlab="X",ylab="Density",type="l",main="",col="red",lty=3)
lines(x.seq$x,0.5*dnorm(x.seq$x,mean=-2,sd=0.5)+0.5*dnorm(x.seq$x,mean=3,sd=1.5),col="black",lty=1)
lines(x.seq$x,fitted(npudens(bws=bw,newdata=x.seq)),col="blue",lty=2)
dev.off()

bw <- npudensbw(~x,bwmethod="cv.ls",bwtype="adaptive_nn")

postscript(file="kernel_ada_lscv.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(density(x),ylim=c(0,0.45),xlab="X",ylab="Density",type="l",main="",col="red",lty=3)
lines(x.seq$x,0.5*dnorm(x.seq$x,mean=-2,sd=0.5)+0.5*dnorm(x.seq$x,mean=3,sd=1.5),col="black",lty=1)
lines(x.seq$x,fitted(npudens(bws=bw,newdata=x.seq)),col="blue",lty=2)
dev.off()

