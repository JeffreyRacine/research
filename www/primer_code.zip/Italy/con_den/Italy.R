library(np)
data("Italy")
Italy$year <- ordered(Italy$year)
names(Italy) <- c("Year","GDP")
attach(Italy)

bw <- npcdensbw(formula=GDP~Year, tol=.1, ftol=.1)

fhat <- npcdens(bws=bw)

summary(fhat)

postscript(file="plot_pdf.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw, view="fixed", main="",theta=300,phi=50,box=FALSE)
dev.off()

postscript(file="plot_cdf.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw, cdf=TRUE, view="fixed", main="",theta=300,phi=50,box=FALSE)
dev.off()
