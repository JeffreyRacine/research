library(np)
data(Italy)
attach(Italy)

bw <- npcdensbw(formula=gdp~ordered(year), tol=.1, ftol=.1)

model.q0.25 <- npqreg(bws=bw, tau=0.25)
model.q0.50 <- npqreg(bws=bw, tau=0.50)
model.q0.75 <- npqreg(bws=bw, tau=0.75)

postscript(file="quantile.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(ordered(year), gdp, 
     main="",
     xlab="Year", 
     ylab="GDP Quantiles")

lines(ordered(year), model.q0.25$quantile, col="green", lty=3, lwd=3)
lines(ordered(year), model.q0.50$quantile, col="blue", lty=1, lwd=2)
lines(ordered(year), model.q0.75$quantile, col="red", lty=2,lwd=3)

legend(ordered(1951), 32, c("0.25", "0.50", "0.75"), 
       lty=c(3, 1, 2), col=c("green", "blue", "red"))
dev.off()
