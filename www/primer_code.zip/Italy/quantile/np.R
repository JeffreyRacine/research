library(np)
data("Italy")
attach(Italy)

bw <- npcdensbw(formula=gdp~ordered(year), tol=.1, ftol=.1)

fhat <- npcdens(bws=bw)

summary(fhat)

postscript(file="cpdf.ps",paper="letter")
plot(bw, view="fixed", main="",theta=300,phi=50)
dev.off()


postscript(file="ccdf.ps",paper="letter")
plot(bw, cdf=TRUE,view="fixed", main="",theta=300,phi=50)
dev.off()
