# Remove all objects in the workspace

rm(list=ls())

library(np)
options(np.messages=FALSE)
library("MASS")
data("birthwt")

bw <- npindexbw(formula=low~
                factor(smoke)+
                factor(race)+
                factor(ht)+
                factor(ui)+
                ordered(ftv)+
                age+
                lwt,
                method="kleinspady",
                nmulti=100,
                data=birthwt)

summary(bw)

model.index <- npindex(bws=bw, gradients=TRUE)

summary(model.index)
