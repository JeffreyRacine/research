library(np)
options(np.messages=FALSE)

data(wage1)
attach(wage1)

expersq <- exper^2

model.lm <- lm(formula=lwage~factor(female)+
               factor(married)+
               educ+
               tenure+
               exper+
               expersq)

summary(model.lm)

bw <- npindexbw(formula=lwage~factor(female)+
                factor(married)+
                educ+
                exper+
                expersq+
                tenure,
                data=wage1)

model <- npindex(bw)

summary(model)
