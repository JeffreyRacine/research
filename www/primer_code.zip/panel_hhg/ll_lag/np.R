library(np)
options(np.messages=FALSE)

data <- read.table("../data/hhg.dat",header=T)
attach(data)

# pat cuspid scisect year logrl0 logrl1 logrl2 logrl3 logrl4 logrl5
# logk

# Lag0

bw <- npregbw(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logk,
              regtype="ll",
              bwmethod="cv.aic",
              nmulti=10)

summary(bw)

model <- npreg(bws=bw)

summary(model)

save(bw,file="lag0.RData")

postscript(file="mean_lag0.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

# Lag1

bw <- npregbw(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logrl1+
              logk,
              regtype="ll",
              bwmethod="cv.aic",
              nmulti=10)

summary(bw)

model <- npreg(bws=bw)

summary(model)

save(bw,file="lag1.RData")

postscript(file="mean_lag1.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

# Lag2

bw <- npregbw(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logrl1+
              logrl2+
              logk,
              regtype="ll",
              bwmethod="cv.aic",
              nmulti=10)

summary(bw)

model <- npreg(bws=bw)

summary(model)

save(bw,file="lag2.RData")

postscript(file="mean_lag2.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

# Lag3

bw <- npregbw(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logrl1+
              logrl2+
              logrl3+
              logk,
              regtype="ll",
              bwmethod="cv.aic",
              nmulti=10)

summary(bw)

model <- npreg(bws=bw)

summary(model)

save(bw,file="lag3.RData")

postscript(file="mean_lag3.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()

# Lag4

bw <- npregbw(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logrl1+
              logrl2+
              logrl3+
              logrl4+
              logk,
              regtype="ll",
              bwmethod="cv.aic",
              nmulti=10)

summary(bw)

model <- npreg(bws=bw)

summary(model)

save(bw,file="lag4.RData")

postscript(file="mean_lag4.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(bw,
     plot.errors.method="bootstrap",
     plot.errors.boot.num=25,common.scale=FALSE)
dev.off()
