library(np)
#options(np.messages=FALSE)

data <- read.table("../data/hhg.dat",header=T)
attach(data)

#pat cuspid scisect year logrl0 logrl1 logrl2 logrl3 logrl4 logrl5 logk

model <- lm(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logrl1+
              logrl2+
              logrl3+
              logrl4+
              logrl5+
              logk-1)

summary(model)

