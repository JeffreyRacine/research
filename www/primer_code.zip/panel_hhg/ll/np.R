library(np)

data <- read.table("../data/hhg.dat",header=T)
attach(data)

#pat cuspid scisect year logrl0 logrl1 logrl2 logrl3 logrl4 logrl5 logk

bw <- npregbw(pat~factor(cuspid)+
              ordered(year)+
              factor(scisect)+
              logrl0+
              logrl1+
              logrl2+
              logrl3+
              logrl4+
              logrl5+
              logk,
              regtype="ll",
              bwmethod="cv.aic",
              nmulti=10)

summary(bw)

model <- npreg(bws=bw)

summary(model)
