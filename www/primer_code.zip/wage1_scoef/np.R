library(np)
options(np.messages=FALSE)

data(wage1)
attach(wage1)

expersq <- exper^2

model.lm <- lm(formula=lwage~factor(female)+
               factor(married)+
               educ+
               tenure+
               exper+
               expersq)

summary(model.lm)

bw <- npscoefbw(formula=lwage~
                educ+
                tenure+
                exper+
                expersq|factor(female)+factor(married))

model.scoef <- npscoef(bw,betas=TRUE)

summary(model.scoef)

## You could examine the matrix of coefficients, or compute the average
## for each variable. One might then compare with the OLS model.

colMeans(coef(model.scoef))

coef(model.lm)
