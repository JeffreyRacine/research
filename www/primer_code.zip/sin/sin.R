library(np)

set.seed(123)

n <- 50
x <- sort(runif(n))

x.seq <- seq(0,1,length=1000)
  
y <- sin(2*pi*x) + rnorm(n,sd=0.25)

bw.lc <- npregbw(y~x,regtype="lc",tol=.1,ftol=.1)
bw.ll <- npregbw(y~x,regtype="ll",tol=.1,ftol=.1)

summary(bw.lc)
summary(bw.ll)

model.lc <- npreg(bws=bw.lc,gradient=TRUE)
model.ll <- npreg(bws=bw.ll,gradient=TRUE)

summary(model.lc)
summary(model.ll)

summary(lm(y~sin(2*pi*x)))

fit.lc <- fitted(model.lc)
fit.ll <- fitted(model.ll)


## Gradients

postscript(file="lscv.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(x,y,cex=0.2)
lines(x.seq,sin(2*pi*x.seq),col="black",lty=1)
lines(x,fit.lc,col="red",lty=2)
lines(x,fit.ll,col="blue",lty=3)
legend(0.5,1.0,c("DGP",paste("LC (h=",signif(bw.lc$bw[1],3), ")",sep=""),paste("LL (h=",signif(bw.ll$bw[1],2), ")",sep="")),col=c("black","red","blue"),lty=c(1,2,3))
dev.off()

## Gradients

postscript(file="lscv_grad.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(x,2*pi*cos(2*pi*x),ylab="dy/dx",col="black",type="l",lty=1)
lines(x,gradients(model.lc)[,1],col="red",lty=2)
lines(x,gradients(model.ll)[,1],col="blue",lty=3)
legend(0.4,6,c("DGP","LC","LL"),col=c("black","red","blue"),lty=c(1,2,3))
dev.off()

bw.lc$bw[1] <- 1e05
bw.ll$bw[1] <- 1e05

model.lc <- npreg(bws=bw.lc,gradient=TRUE)
model.ll <- npreg(bws=bw.ll,gradient=TRUE)

fit.lc <- fitted(model.lc)
fit.ll <- fitted(model.ll)

postscript(file="h_inf.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
plot(x,y,cex=0.2)
lines(x.seq,sin(2*pi*x.seq),col="black",lty=1)
lines(x,fit.lc,col="red",lty=2)
lines(x,fit.ll,col="blue",lty=3)
legend(0.5,1.0,c("DGP",paste("LC (h=",signif(bw.lc$bw[1],3), ")",sep=""),paste("LL (h=",signif(bw.ll$bw[1],2), ")",sep="")),col=c("black","red","blue"),lty=c(1,2,3))
dev.off()
