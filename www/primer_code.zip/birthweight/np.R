   library("MASS")
     data("birthwt")
     attach(birthwt)

     # Fit a parametric logit model with low (0/1) as the dependent
     # variable and age, lwt, and smoke (0/1) as the covariates

     # From ?birthwt
     # 'low' indicator of birth weight less than 2.5kg
     # 'smoke' smoking status during pregnancy
     # 'race' mother's race ('1' = white, '2' = black, '3' = other)
     # 'ht' history of hypertension
     # 'ui' presence of uterine irritability
     # 'ftv' number of physician visits during the first trimester
     # 'age' mother's age in years
     # 'lwt' mother's weight in pounds at last menstrual period

     model.logit <- glm(low~factor(smoke)+
                        factor(race)+
                        factor(ht)+
                        factor(ui)+
                        ordered(ftv)+
                        age+
                        lwt, 
                        family=binomial(link=logit))

     # Generate the confusion matrix and correct classification ratio

     cm <- table(low, ifelse(fitted(model.logit)>0.5, 1, 0))
     ccr <- sum(diag(cm))/sum(cm)

     # Now do the same with a nonparametric model...

     X <- data.frame(factor(smoke), 
                     factor(race), 
                     factor(ht), 
                     factor(ui), 
                     ordered(ftv), 
                     age, 
                     lwt)

     y <- factor(low)

     # Note - this may take a few minutes depending on the speed of your
     # computer... we override the default search tolerances for speed
     # considerations...

     bw <- npcdensbw(xdat=X, ydat=y, tol=.1, ftol=.1)

     model.np <- npconmode(bws=bw)

     summary(model.np)

