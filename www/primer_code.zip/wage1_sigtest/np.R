library(np)
options(np.messages=FALSE)

data(wage1)

#bw.all <- npregbw(formula=lwage~factor(female)+
#                  factor(married)+
#                  educ+
#                  exper+
#                  tenure,
#                  regtype="ll",
#                  bwmethod="cv.aic",
#                  data=wage1)

#save(bw,file="bw.RData")

summary(bw.all)

model.np <- npreg(bws=bw.all)

summary(model.np)

output <- npsigtest(bws=bw.all)

summary(output)
