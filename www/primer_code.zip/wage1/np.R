library(np)
options(np.messages=FALSE)
library(scatterplot3d)
data(wage1)
attach(wage1)

bw <- npudensbw(~lwage+ordered(numdep),tol=.1,ftol=.1,data=wage1)

numdep.seq <- sort(unique(numdep))
lwage.seq <- seq(min(lwage),max(lwage),length=50)
wage1.eval <- expand.grid(numdep=ordered(numdep.seq),lwage=lwage.seq)

fhat <- fitted(npudens(bws=bw,newdata=wage1.eval))

f <- matrix(fhat,length(unique(numdep)),50)

postscript(file="persp.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
persp(numdep.seq,
      lwage.seq,
      f,
      ticktype="detailed", 
      ylab="Log wage",
      xlab="Number of Dependents",
      zlab="Joint Density",
      theta=110,
      phi=40)
dev.off()


postscript(file="scatter.ps",horizontal=FALSE,pagecentre=FALSE,height=8.5,width=8.5,pointsize=16,paper="special")
## Hack since scatterplot converts ordered 0-6 to numeric 1-7
scatterplot3d(as.numeric(wage1.eval[,1])-1,wage1.eval[,2],fhat,
              ylab="Log wage",
              xlab="Number of Dependents",
              zlab="Joint Density",
              angle=15,box=FALSE,type="h",grid=TRUE,color="blue")
dev.off()

summary(bw)

library(xtable)

xtable(table(numdep))
